#ifndef MAP_H_INCLUDED
#define MAP_H_INCLUDED

    #include "global.h"
    #include "color.h"
    #include "camera.h"

    void setMapSize(int x, int y);
    intVector2D getMapSize();

    bool isPointWithinBox(vector2D point, vector2D boxPosition, vector2D boxSize);
    bool isBoxOverlappingBox(vector2D box1Position, vector2D box1Size, vector2D box2Position, vector2D box2Size);
    bool isWithinTheMap(vector2D point, vector2D size);
    bool detectCollision(vector2D position, vector2D size, block collidableBlock, block** collidedWith);

    void freeColorMap();
    void generateColorMap();

    void freeMap();
    void createMap();
    void generateMap(vector2D maxVelocity);
    block** getMap();

    int getHeightAtX(int x);
    bool isInBlockSideways(int x, int lowestY, int uppermostY);
    bool isInBlockPerpendicular(int leftmostX, int rightmostX, int y);
    renderObject getBlockRenderObject(int x, int* y, int direction, int bound, bool sides[]);

#endif // MAP_H_INCLUDED
