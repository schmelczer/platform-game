#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>

#include <wchar.h>
#include <locale.h>

#include <SDL.h>
#include <SDL_ttf.h>
#include <SDL_gfxPrimitives.h>

#include "auxiliary/auxFunctions.h"

#ifndef GLOBAL_H_INCLUDED
#define GLOBAL_H_INCLUDED

#define FPS (int) 50

float g;

///<Glob�lis v�ltoz�k>
SDL_Surface* screen;
TTF_Font* fontSmaller;
TTF_Font* fontSmall;
TTF_Font* fontSmallBold;
TTF_Font* fontLarge;
SDL_Surface* text;
unsigned char* keys;
///</Glob�lis v�ltoz�k>


///<Vektorok>
typedef struct vector2D {
    //1 egys�g == 1m
    float x, y;
} vector2D;

typedef struct intVector2D {
    int x, y;
} intVector2D;

typedef struct vector3D {
    //1 egys�g == 1m
    float x, y, z;
} vector3D;
///</Vektorok>


///<Sz�nek>
typedef struct color {
    unsigned char r, g, b, a;
} color;

typedef struct colors {
    color light, normal, dark;
} colors;
///</Sz�nek>


typedef enum block {
    air, solid, invisible, treasure
} block;


typedef struct renderObject {
    vector3D position;
    vector3D size;
    colors colors;
    bool doesExist;
} renderObject;

#endif // GLOBAL_H_INCLUDED
